package hotchemi.android.rate;

public interface OnClickButtonListener {

    void onClickButton(int which);

}