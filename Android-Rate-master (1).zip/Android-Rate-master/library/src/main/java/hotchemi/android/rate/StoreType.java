package hotchemi.android.rate;

public enum StoreType {
    GOOGLEPLAY,
    AMAZON
}